
/* makedos.c - Change a Terak filename into something DOS-compatible */
/* Copyright 1994 Syndesis Corporation */
/* July 12, 1990 */

#include <stdio.h>
#include <string.h>

#include "teradecl.h"
#include "teravars.h"


void makeDOSname( char *newname )
{
char *ptr;
int hit;


    /* Only allow one period in name.  This terminates the name at the second period. */
    hit = 0;
    ptr = newname;
    while (*ptr) {
        if (*ptr == '.' && hit == 1) {
            *ptr = 0;
            break;
        }
        if (*ptr == '.' && hit == 0) {
            hit = 1;
        }
        ptr ++;
    }

    /* Should really change this so it uses the trailing extension, 
      since many Terak names are more likely to have a differentiating end extension than a middle extent. */

    /* Change all '/' to '_' */
    ptr = newname;
    while (*ptr) {
        if (*ptr == '/') {
            *ptr = '_';
        }
        ptr ++;
    }
}

