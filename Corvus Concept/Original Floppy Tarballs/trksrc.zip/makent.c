                                                          
/* makent.c - Insure a filename is WinNT compatible */
/* Copyright 1994 Syndesis Corporation, by John Foust <jfoust@threedee.com> */
/* March 17, 1998 */

#include <stdio.h>
#include <string.h>

#include "diskdecl.h"


/* For WinNT, insure filenames are DOS-friendly */

void makeWinNTname( char *str )
{
#if defined(_MSC_VER)

    while (*str) {

        /* UCSD allows this */
        if (*str == '\\') {
            *str = '_';
        }
        else if (*str == '/') {
            *str = '_';
        }

        /* */

        str ++;
    }
#endif
}

