
#include <stdio.h>
#include <string.h>

#include "diskdecl.h"

#include "ucsddecl.h"
#include "ucsdvars.h"


USHORT ucsdPrintVolInfo( ucsdDirRoot *dirRoot, short freespace )
{
    printf( "\nVolume %s has %hd files,  ", 
        dirRoot->volName, dirRoot->numFiles );

    /* printf( "firstBlk %hd, lastBlk %hd, eovBlk %hd, size %hd, free %hd\n\n", */
    printf( "%hd to %hd (%hd), eov %hd, size %hd, free %hd\n\n",
        dirRoot->firstBlk, dirRoot->lastBlk, 
        dirRoot->lastBlk - dirRoot->firstBlk, 
        dirRoot->eovBlk, freespace );

    return TE_NOERROR;
}

