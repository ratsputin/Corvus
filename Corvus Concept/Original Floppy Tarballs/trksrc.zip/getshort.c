
#include <stdio.h>
#include <string.h>

#include "diskdecl.h"

#include "ucsddecl.h"
#include "ucsdvars.h"


/* Read a 16-bit 'short', and swap if necessary */

USHORT getShort( FILE *infp, short *val )
{
USHORT lerr;


    if (fread( val, sizeof(short), (size_t) 1, infp ) != 1) {
        lerr = TE_BADREAD;
        goto out;
    }
    /* SWAB( (char *) val ); */

    /* Swap if necessary */
    if (doSwab == TRUE) {
        swabShort( val );
    }

    lerr = TE_NOERROR;
out:
    return lerr;
}

