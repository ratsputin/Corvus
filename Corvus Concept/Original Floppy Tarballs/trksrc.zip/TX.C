
/* Filter to convert Terak compressed text files to Amiga files */
/* Copyright 1990 by John Foust */
/* July 12, 1990 */

#include <stdio.h>

#if defined(_MSC_VER)
#include <fcntl.h>
#include <io.h>
#endif

#define DLE 16


int main( int argc, char **argv )
{
int each;
int ch;


#if defined(_MSC_VER)
    /* Set "stdin" to have binary mode: */
    _setmode( _fileno( stdin ), _O_BINARY );
#endif

    while ( (ch=getchar()) != -1) {

        /* Handle indents at front of line */
        if (ch == DLE) {
            /* Get indent amount, where 32 means indent 0 */
            ch = getchar();
            if (ch >= 32) {
                ch = ch - 32;
                for (each=0; each<ch; each++) {
                   putchar(' ');
                }
            }
        }
        /* If a CR, output newline */
        else if (ch == 0x0D) {
            putchar('\n');
        }
        /* Skip nulls, but output everything else */
        else if (ch != 0) {
            putchar(ch);
        }
    }

    return 0;
}

 

 

/* SETMODE.C: This program uses _setmode to change
 * stdin from text mode to binary mode.
 */

#include <stdio.h>


 

