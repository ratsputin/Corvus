
/* calcfree.c - Find free space on UCSD disk image */
/* Copyright 1994 Syndesis Corporation */
/* July 12, 1990 */

#include <stdio.h>
#include <string.h>

#include "diskdecl.h"

#include "ucsddecl.h"
#include "ucsdvars.h"


short ucsdCalcFreeSpace( ucsdDirRoot *dirRoot, ucsdDirEntry *dir )
{
short freespace;
ucsdDirEntry *eachEntry;
short each;


    freespace = 0;

    /* Volume size */
    freespace = dirRoot->eovBlk - dirRoot->lastBlk;

    /* Subtract each file size */
    eachEntry = dir;
    for (each=0; each<dirRoot->numFiles; each++) {
        freespace -= (eachEntry->lastBlk - eachEntry->firstBlk);
        eachEntry ++;
    }

    return freespace;
}

