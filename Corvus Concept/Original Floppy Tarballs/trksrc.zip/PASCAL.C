
/* Pascal strings have a length byte at the start */

void unPascalStr( char *str )
{
short eachch;
short len;


    len = (short) *str;
    for (eachch=0; eachch<len; eachch++) {
        str[ eachch ] = str[ eachch + 1 ];
        str[ eachch + 1 ] = 0;
    }
}


