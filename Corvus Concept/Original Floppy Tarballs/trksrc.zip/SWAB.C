
/* swab.c - Swap bytes */

#include <stdio.h>
#include <string.h>

#include "diskdecl.h"

#include "ucsddecl.h"


/* Swap the two bytes of a short */
/* Perform the Intel to Motorola swap on non-Intel platforms */

void mySwab( char *ptr )
{
#if defined(MOTOROLA_BYTE_ORDER)
char c;
char *sptr;


    sptr = (ptr + 1);
    c = *ptr;
    *ptr = *sptr;
    *sptr = c;
#endif
}


void swabShort( short *shPtr )
{
char c;
char *sptr;
char *ptr;


    ptr = (char *) shPtr;

    sptr = (ptr + 1);
    c = *ptr;
    *ptr = *sptr;
    *sptr = c;
}

