
/* ucsdvars.h - Variables for UCSD file systems */
/* Copyright 1994 Syndesis Corporation */

#ifdef MyGLOBAL
#undef MyGLOBAL
#endif

#ifdef STR_DEF
#undef STR_DEF
#endif

#ifdef PRIMARY
 #define MyGLOBAL
 #define VAR_DEF( a )    = a
#else
 #define MyGLOBAL extern
 #define VAR_DEF( a )
#endif


/* Whether we need to swap endian or not */

int doSwab;

