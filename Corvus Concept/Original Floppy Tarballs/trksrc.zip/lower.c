
#include <stdio.h>


/* Convert string to lowercase */

void strLower( char *str )
{
char *cptr;


    if (str == NULL) {
        return;
    }

    cptr = str;
    while (*cptr != 0) {

        if (*cptr >= 'A' && *cptr <= 'Z') {

            *cptr = (*cptr + ('a' - 'A'));
        }

        cptr ++;
    }
}

